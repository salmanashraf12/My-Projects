import { validateEmail } from "./validate-email";
import { validateImageType } from "./validate-image";

export { validateImageType, validateEmail };
