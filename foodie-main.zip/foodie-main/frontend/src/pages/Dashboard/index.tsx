import { AddRecipe } from "./add-recipe";
import { MyRecipes } from "./my-recipes";
import { More } from "./more";
import { Home } from "./home";

export { AddRecipe, MyRecipes, More, Home };
