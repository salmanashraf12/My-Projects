import { instance } from "./axios";
export { instance };
