import { authenticate } from "./passport";

export { authenticate };
