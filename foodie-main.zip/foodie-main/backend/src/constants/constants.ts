export const enum CONSTANTS {
  SALT = 12,
}
