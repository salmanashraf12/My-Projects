import { router as recipeRouter } from "./recipes";
import { router as authRouter } from "./auth";
export { recipeRouter, authRouter };
